<footer style="text-align:center; padding:16px; margin-top:32px; color:#666;">
  &copy; <?php echo date("Y"); ?> Grand Palace Hotel — All rights reserved.
</footer>
</body>
</html>

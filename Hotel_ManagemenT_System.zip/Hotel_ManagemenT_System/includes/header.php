<?php
// Start session if not started
if (session_status() == PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Grand Palace Hotel</title>
<link rel="stylesheet" href="/hotel_management_system/css/homepage.css">
</head>
<body>
    
<header>
    <center>
<h1>Grand Palace Hotel</h1>
<p>“Step into Comfort, Stay with Elegance"</p>
</center>
</header>
